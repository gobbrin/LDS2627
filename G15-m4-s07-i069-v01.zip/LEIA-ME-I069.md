# I069 — Estrutura do frontend web e integração com API

Grupo G15 · M4 / Sprint 07 · 2026-11-08.

Este pacote contém apenas os 46 ficheiros novos da I069, preservando a
hierarquia do repositório, e um patch alternativo. Não contém o backend,
node_modules, builds, segredos ou dados reais de contas.

Base: 069764e07b12301bc88f1a79ad6fbfe7a54ff56e (`develop`).
Branch local: feature/i069-estrutura-frontend-web.
Último commit local: 5c387a1fb6f49dce680d44ac95f45be522ea1e62.
A branch ainda não foi publicada no GitHub.

## Aplicação ao repositório

Escolher uma das alternativas; não aplicar ambas:

1. Copiar `.github/workflows/frontend-web-ci.yml` e a pasta
   `projeto/04-artefactos-tecnicos/04.14-frontend-web/m4-v01` para uma branch de
   trabalho baseada na versão indicada. Antes, verificar se entretanto existem
   alterações de outros elementos nessas pastas, para não as substituir.
2. Com o repositório nessa base e sem ficheiros em conflito, verificar
   `git apply --check I069.patch` e depois aplicar `git apply I069.patch`.

## Executar

```sh
cd projeto/04-artefactos-tecnicos/04.14-frontend-web/m4-v01
npm ci
npm start
```

Abrir http://localhost:4200. Configurar o backend em `public/config.json`.
Ler o README dessa pasta para sessão, contratos, CORS, testes e extensão na I070.

## Validação

- Passaram Prettier, ESLint, compilação de produção e os 36 testes suplementares
  (`npm run test:dom`, Angular AOT + Jasmine + DOM simulado).
- Chrome/Karma não executou devido ao bloqueio do browser pelo ambiente;
  cobertura oficial ainda não medida, limiar de 80% configurado.
- API pública respondeu a /health, mas o preflight CORS da origem local devolveu
  405; integração autenticada real ainda por validar.
- A publicação no GitHub foi bloqueada pela revisão automática, que pediu
  autorização explícita para enviar o conjunto de ficheiros ao repositório remoto.
- Revisão, auditoria e merge não realizados. A Issue não foi marcada como Done.

Detalhes e fontes: `docs/m4-s07-i069-evidencias-v01.md`, na pasta do frontend.
